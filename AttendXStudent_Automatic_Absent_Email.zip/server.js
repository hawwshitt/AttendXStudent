// Optional local email sender.
// The website itself works without this server and creates mailto drafts.
// If you want real automatic sending, configure SMTP below and run: npm install && npm start
const express=require("express"), nodemailer=require("nodemailer"), path=require("path");
const app=express();app.use(express.json());app.use(express.static(__dirname));
const port=process.env.PORT||3000;
const transporter=nodemailer.createTransport({
 host:process.env.SMTP_HOST, port:Number(process.env.SMTP_PORT||587),
 secure:process.env.SMTP_SECURE==="true",
 auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS}
});
app.post("/api/send-reminder",async(req,res)=>{
 try{
  const {to,subject,body}=req.body;
  if(!to) return res.status(400).json({error:"Recipient email required"});
  await transporter.sendMail({from:process.env.MAIL_FROM||process.env.SMTP_USER,to,subject,text:body});
  res.json({ok:true});
 }catch(e){res.status(500).json({error:e.message})}
});
app.listen(port,()=>console.log(`AttendXStudent running at http://localhost:${port}`));
